# FestoProject > 2024-04-21 4:06pm
https://universe.roboflow.com/festo/festoproject-cjyma

Provided by a Roboflow user
License: CC BY 4.0

